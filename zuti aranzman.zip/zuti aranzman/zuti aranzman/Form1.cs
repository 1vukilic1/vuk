﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace zuti_aranzman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listView1.Visible = false;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        int redbr = 0;
        string putanja= @"E:\zuti aranzman\cene.txt";
        private void button1_Click(object sender, EventArgs e)
        {
           
            listView1.Visible = true;
            string s9 = "100";
            string[] aranzman = File.ReadAllLines(putanja);
            for (int i = 0; i < aranzman.Length; i += 2)
            {
                if (aranzman[i] == comboBox1.Text)
                {
                    if (comboBox2.Text == "AUTOBUS")
                        s9 = aranzman[i + 1];
                    else
                        s9 = aranzman[i + 2];
                }
                if (aranzman[i] == comboBox1.Text)
                {
                    if (comboBox2.Text == "AVION")
                        s9 = aranzman[i + 2];
                    else
                        s9 = aranzman[i + 1];
                }
            }
           

            string s0 = Convert.ToString(redbr);
            string s1 = textBox2.Text;
            string s2 = textBox1.Text;
            string s3 = comboBox2.Text;
            string s4 = comboBox3.Text;
            string s6 = textBox3.Text;
            int k = Convert.ToInt32(s9);
            int k1 = Convert.ToInt32(s6);
            int m = k * k1;
            string s7 = Convert.ToString(m);
            string[] zapis = { s0, s1, s2, s3, s4, s9, s6 , s7};
            var red = new ListViewItem(zapis);
            listView1.Items.Add(red);
            redbr++;
        }
        string FAJL = @"E:\zuti aranzman\cene.txt";
        private void Form1_Load(object sender, EventArgs e)
        {
            string[] linije = File.ReadAllLines(FAJL);
            for (int i = 0; i < linije.Length; i += 3) comboBox1.Items.Add(linije[i]);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string naziv = @"E:\zuti aranzman\cuvanje.txt";
            System.IO.StreamWriter snimi = new System.IO.StreamWriter(naziv);
            int k = listView1.Items.Count;
            for (int i = 0; i < k; i++)
            {
                string s = listView1.Items[i].ToString();
                snimi.WriteLine(s);
            }
            snimi.Close();
            MessageBox.Show("SNIMLJENO!!");
            try
            {
                using (var tw = new StreamWriter(@"D:\podaci2.txt"))
                {
                    foreach (ListViewItem item in listView1.Items)
                    {
                        foreach (ListViewItem.ListViewSubItem subItem in item.SubItems)
                        {
                            tw.Write(subItem.Text + "\t");
                        }
                        tw.WriteLine();
                    }
                }
                Console.WriteLine("Snimljeno.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Niste snimili: " + ex.Message);
            }
        }
    }
}
