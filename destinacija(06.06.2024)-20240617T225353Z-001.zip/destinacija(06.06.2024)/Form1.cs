﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace destinacija_06._06._2024_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string putanja = @"D:\III Programiranje\Grupa A\Vuk Ilic\pit\destinacija(06.06.2024)\lokacija.txt";
        private void tabPage1_Click(object sender, EventArgs e)
        {


        }
        string[] aranzman;

        private void Form1_Load(object sender, EventArgs e)
        {
            aranzman = File.ReadAllLines(putanja);
            for (int i = 0; i < aranzman.Length; i += 2)
            {
                comboBox3.Items.Add(aranzman[i]);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s0 = Convert.ToString(listView1.Items.Count + 1);
            string s1 = comboBox3.Text;
            string s2 = "0";
            string[] kilometar = File.ReadAllLines(putanja);
            for (int i = 0; i < kilometar.Length; i += 2)
            {
               if(kilometar[i]==comboBox3.Text)
                {
                    s2 = kilometar[i + 1];
                }
              
            }
            string s3 = dateTimePicker1.Text;
            string s4 = comboBox4.Text;
            string[]s = { s0, s1, s2, s3, s4 };
            var red = new ListViewItem(s);
            listView1.Items.Add(red);
            button6.PerformClick();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int zbir = 0;
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                zbir += Convert.ToInt32(listView1.Items[i].SubItems[2].Text);
            }
            label7.Text = Convert.ToString(zbir);

            float brojac1 = Convert.ToInt32(textBox1.Text);
            float brojac2 = Convert.ToInt32(textBox2.Text);
            float brojac = (brojac1 * (zbir / 100) * brojac2);
            label8.Text = Convert.ToString(brojac);
            int br = Convert.ToInt32(label7.Text) * 2;
            label13.Text = Convert.ToString(br);
            int mr = Convert.ToInt32(label8.Text) * 2;
            label14.Text = Convert.ToString(mr);
        }
    }
}