﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace zadatak_7___programiranje_stankovic___combo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)  
        {

        }

         

        string putanja1 = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\combo1A(28.05.2024)\korisnik.txt";
        string putanja2 = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\combo1A(28.05.2024)\aktivnost.txt");



        private void button1_Click(object sender, EventArgs e) //UCITAJ
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox1.DataSource = File.ReadAllLines(@"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\combo1A(28.05.2024)\korisnik.txt");
            comboBox2.DataSource = File.ReadAllLines(@"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\combo1A(28.05.2024)\korisnik.txt");
            comboBox1.Text = "";
            comboBox2.Text = "";
        }

        private void button2_Click(object sender, EventArgs e) //POTVRDITE
        {
            int k = 0;
            k = listView1.Items.Count;
            k++;
            string s0 = Convert.ToString(k);
            string s1 = comboBox1.Text;
            string s2 = comboBox2.Text;
            string s3 = comboBox3.Text;
            string s4 = comboBox4.Text;
            string s5 = comboBox5.Text;
            string[] zapis = { s0, s1, s2, s3, s4, s5 };
            var red = new ListViewItem(zapis);
            listView1.Items.Add(red);
            comboBox1.Text="";
            comboBox2.Text="";
            comboBox3.Text="";
            comboBox4.Text="";
            comboBox5.Text="";

        }

        private void button3_Click(object sender, EventArgs e) //PROVERITE
        {
            listView2.Items.Clear();
            int k = listView1.Items.Count;
            int p = listView2.Items.Count;
            string dan = comboBox6.Text;
            for(int i=0;i<k;i++)
            {
                if (listView1.Items[i].SubItems[3].Text==dan)
                {
                    p++;
                    string s0 = Convert.ToString(p);
                    string s1 = listView1.Items[i].SubItems[1].Text;
                    string s2 = listView1.Items[i].SubItems[2].Text;
                    string s3 = listView1.Items[i].SubItems[3].Text;
                    string s4 = listView1.Items[i].SubItems[4].Text;
                    string s5 = listView1.Items[i].SubItems[5].Text;
                    string[] zapis = { s0, s1, s2, s3, s4, s5 };
                    var red = new ListViewItem(zapis);
                    listView2.Items.Add(red);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e) //UCITATI KORISNIKA
        {
            if(textBox1.Text==" ")
            {
                MessageBox.Show("Morate uneti korisnika!!");
            }
            else { 
            try
            {
                string[] zapis = new string[] 
                {
                    textBox1.Text
                }; 
                File.AppendAllLines(putanja1, zapis);
            }
            catch (IOException e1)
            {
                MessageBox.Show("Nije moguce ucitati.");
            }
            tabControl1.SelectedIndex = 0;
            }
        }

        private void button5_Click(object sender, EventArgs e) //UCITAJ AKTIVNOST
        {
            if(textBox2.Text=="")
            {
                MessageBox.Show("Morate uneti aktivnost!!");
            }
            else { 
            try
            {
                string[] zapis = new string[]
                {
                    textBox2.Text
                };
                File.AppendAllLines(putanja2, zapis);
            }
            catch (IOException e1)
            {
                MessageBox.Show("Nije moguce ucitati.");
            }
            tabControl1.SelectedIndex = 0;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;

        }

        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
        }
    }
}
