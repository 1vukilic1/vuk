﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace biblioteka
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string FAJL_korisnici = @"D:\III Programiranje\GRUPA A\Vuk Ilic \Programiranje\C#\biblioteka\biblioteka\podaci\prvi.txt";
        string FAJL_knjige = @"D:\III Programiranje\GRUPA A\Vuk Ilic \Programiranje\C#\biblioteka\biblioteka\podaci\drugi.txt";
        string FAJL_uzete = @"D:\III Programiranje\GRUPA A\Vuk Ilic \Programiranje\C#\biblioteka\biblioteka\podaci\treci.txt";
        private void Form1_Load(object sender, EventArgs e)
        {
            reload();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0 && listBox2.SelectedIndex >= 0)
            {
                StreamWriter pisi = new StreamWriter(FAJL_uzete,true);
                pisi.WriteLine(listBox1.Items[listBox1.SelectedIndex]);
                pisi.WriteLine(listBox2.Items[listBox2.SelectedIndex]);
                pisi.WriteLine(dateTimePicker1.Text);
                pisi.WriteLine("NA CITANJU");
                pisi.Close();
                string knjiga = listBox2.Items[listBox2.SelectedIndex].ToString();
                listBox1.SelectedIndex = -1;
                listBox2.SelectedIndex = -1;
                string[] linije = File.ReadAllLines(FAJL_knjige);
                for(int i = 0; i < linije.Length; i++)
                {
                    if (linije[i] == knjiga) linije[i + 1] = "Zauzeta";
                }
                File.WriteAllLines(FAJL_knjige,linije);
            }
            else
                MessageBox.Show("Morate izabrati i korisnika i knjigu.");
            reload();
        }
        public void reload()
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listView1.Items.Clear();
            string red;
            StreamReader citaj = new StreamReader(FAJL_korisnici);
            while ((red = citaj.ReadLine()) != null)
            {
                listBox1.Items.Add(red);
            }
            citaj.Close();
            StreamReader citaj2 = new StreamReader(FAJL_knjige);
            while ((red = citaj2.ReadLine()) != null)
            {
                if (citaj2.ReadLine() == "Slobodna")
                    listBox2.Items.Add(red);
                else
                    listBox3.Items.Add(red);
            }
            citaj2.Close();
            StreamReader citaj3 = new StreamReader(FAJL_uzete);
            while ((red = citaj3.ReadLine()) != null)
            {
                string s1 = citaj3.ReadLine();
                string s2 = citaj3.ReadLine();
                string s3 = citaj3.ReadLine();
                string[] zapis = { s1, red, s2, s3 };
                var red2 = new ListViewItem(zapis);
                listView1.Items.Add(red2);
            }
            citaj3.Close();
            Dictionary<string, int> brojKnjiga = new Dictionary<string, int>();
            string[] linije = File.ReadAllLines(FAJL_uzete);
            for(int i=1;i<linije.Length;i+=4)
            {
                string linija = linije[i];
                if (brojKnjiga.ContainsKey(linija)) brojKnjiga[linija]++;
                else brojKnjiga[linija] = 1;
            }
            string najknjiga = null;
            int max = 0;
            foreach(var pair in brojKnjiga)
            {
                if (pair.Value > max)
                {
                    najknjiga = pair.Key;
                    max = pair.Value;
                }
            }
            if (najknjiga != null) label2.Text = najknjiga;

            Dictionary<string, int> brojKorisnika = new Dictionary<string, int>();
            string[] korisnici = File.ReadAllLines(FAJL_uzete);
            for (int i = 0; i < korisnici.Length; i += 4)
            {
                string linija = korisnici[i];
                if (brojKorisnika.ContainsKey(linija)) brojKorisnika[linija]++;
                else brojKorisnika[linija] = 1;
            }
            string najkor = null;
            int maxx = 0;
            foreach (var pairr in brojKorisnika)
            {
                if (pairr.Value > maxx)
                {
                    najkor = pairr.Key;
                    maxx = pairr.Value;
                }
            }
            if (najkor != null) label1.Text = najkor;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedIndex >= 0 )
            {
                string[] linije2 = File.ReadAllLines(FAJL_uzete);
                for (int i = 0; i < linije2.Length; i++)
                {
                    if (linije2[i] == listBox3.Items[listBox3.SelectedIndex].ToString()) linije2[i + 2] = dateTimePicker2.Text;
                }
                File.WriteAllLines(FAJL_uzete, linije2);

                string[] linije = File.ReadAllLines(FAJL_knjige);
                for (int i = 0; i < linije.Length; i++)
                {
                    if (linije[i] == listBox3.Items[listBox3.SelectedIndex].ToString()) linije[i + 1] = "Slobodna ";
                }
                File.WriteAllLines(FAJL_knjige, linije); 
            }
            else
                MessageBox.Show("Morate izabrati knjigu.");
            reload();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
