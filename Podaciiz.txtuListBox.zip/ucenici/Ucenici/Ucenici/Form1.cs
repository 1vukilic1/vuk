﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ucenici
{
    public partial class Form1 : Form
    {
        string putanja = @"D:\III Programiranje\Grupa A\Nikola Marinkovic\Ucenici\ucenici.txt";
        int broj = 0;
        int red = -1;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "")
            {
                string prazno = "                               ";
                string s1 = textBox1.Text + prazno;
                string s2 = textBox2.Text + prazno;
                string s3 = textBox3.Text + prazno;
                string s4 = textBox4.Text + prazno;
                int k = listBox1.Items.Count;
                string s0 = Convert.ToString(k + 1) + prazno;
                s0 = s0.Substring(0, 5);
                s1 = s1.Substring(0, 15);
                s2 = s2.Substring(0, 10);
                s3 = s3.Substring(0, 20);
                s4 = s4.Substring(0, 15);
                string s = s0 + s1 + s2 + s3 + s4;
                listBox1.Items.Add(s);
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox1.Focus();
            }
            else MessageBox.Show("Morate uneti sve podatke da bi ih mogli upisati u listu!!!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string prazno = "                               ";
            string s1 = textBox1.Text + prazno;
            string s2 = textBox2.Text + prazno;
            string s3 = textBox3.Text + prazno;
            string s4 = textBox4.Text + prazno;
            s1 = s1.Substring(0, 15);
            s2 = s2.Substring(0, 10);
            s3 = s3.Substring(0, 20);
            s4 = s4.Substring(0, 15);
            int z = listBox1.SelectedIndex;
            string s0 = Convert.ToString(z+1) + prazno;
            s0 = s0.Substring(0, 5);
            string s = s0 + s1 + s2 + s3 + s4;
            listBox1.Items[z] = s;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox1.Focus();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.DataSource = File.ReadAllLines(putanja);
            string prazno = "                               ";
            for (int i=0;i<listBox2.Items.Count/4;i++)
            {
                string s1 = listBox2.Items[broj] + prazno;
                broj = broj+1;
                string s2 = listBox2.Items[broj] + prazno;
                broj = broj+1;
                string s3 = listBox2.Items[broj] + prazno;
                broj = broj+1;
                string s4 = listBox2.Items[broj] + prazno;
                broj = broj+1;
                int k = listBox1.Items.Count;
                string s0 = Convert.ToString(k + 1) + prazno;
                s0 = s0.Substring(0, 5);
                s1 = s1.Substring(0, 15);
                s2 = s2.Substring(0, 10);
                s3 = s3.Substring(0, 20);
                s4 = s4.Substring(0, 15);
                string s = s0 + s1 + s2 + s3 + s4;
                listBox1.Items.Add(s);
            }
            broj = 0;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.IO.StreamWriter snimi = new System.IO.StreamWriter(putanja);
            for(int i=0;i<listBox1.Items.Count;i++)
            {
                string s = listBox1.Items[i].ToString();
                string s1 = s.Substring(5, 15);
                string s2 = s.Substring(20, 10);
                string s3 = s.Substring(30, 20);
                string s4 = s.Substring(50, 15);
                snimi.WriteLine(s1);
                snimi.WriteLine(s2);
                snimi.WriteLine(s3);
                snimi.WriteLine(s4);
            }
            snimi.Close();
            MessageBox.Show("Snimljeno!!!");
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            int k = listBox1.SelectedIndex;
            red = k;
            string s = listBox1.Items[k].ToString();
            string s1 = s.Substring(5, 15);
            string s2 = s.Substring(20, 10);
            string s3 = s.Substring(30, 20);
            string s4 = s.Substring(50, 15);
            textBox1.Text = s1;
            textBox2.Text = s2;
            textBox3.Text = s3;
            textBox4.Text = s4;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult odgovor = MessageBox.Show("Da li ste sigurni da zelite da obrisete red?", "POTVRDA:", MessageBoxButtons.YesNo);
            if (odgovor == DialogResult.Yes)
            {
                listBox1.Items.RemoveAt(red);
                button6.PerformClick();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                red = -1;
            }
            else MessageBox.Show("PRVO IZABERITE RED!!!!");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string prazno = "                                                                                                    ";
            int k = listBox1.Items.Count;
            for (int i = 0; i < k; i++)
            {
                string s = listBox1.Items[i].ToString();
                string s0 = s.Substring(5, s.Length - 5);
                string s1 = Convert.ToString(i + 1);
                s1 = s1 + prazno;
                s1 = s1.Substring(0, 5);
                string final = s1 + s0;
                listBox1.Items[i] = final;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button4.PerformClick();
        }
    }
}
