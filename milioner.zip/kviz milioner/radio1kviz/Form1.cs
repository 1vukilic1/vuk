﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace radio1kviz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int maxbroj = 0;
        int trenutno = -1;
        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = File.ReadAllLines(@"D:\III PROGRAMIRANJE\Grupa A\Vuk Ilic\pit\pitanja.txt");
            listBox2.DataSource = File.ReadAllLines(@"D:\III PROGRAMIRANJE\Grupa A\Vuk Ilic\pit\odgovori.txt");
            listBox3.DataSource = File.ReadAllLines(@"D:\III PROGRAMIRANJE\Grupa A\Vuk Ilic\pit\tacno.txt");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (trenutno > -1) button2.PerformClick();
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            int k = listBox1.Items.Count;
            maxbroj = k;
            Random x = new Random();
            int pitanje = x.Next(0, maxbroj);
            trenutno = pitanje;
            label1.Text = listBox1.Items[pitanje].ToString();
            int odgovor = pitanje * 4;
            radioButton1.Text = listBox2.Items[odgovor].ToString();
            radioButton2.Text = listBox2.Items[odgovor+1].ToString();
            radioButton3.Text = listBox2.Items[odgovor+2].ToString();
            radioButton4.Text = listBox2.Items[odgovor+3].ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string tacno = listBox3.Items[trenutno].ToString();
            int poen = 0;
            MessageBox.Show("Tacan odgovor je pod brojem " + tacno);
            if ((radioButton1.Checked == true) && (tacno == "1")) poen ++;
            if ((radioButton2.Checked == true) && (tacno == "2")) poen ++;
            if ((radioButton3.Checked == true) && (tacno == "3")) poen ++;
            if ((radioButton4.Checked == true) && (tacno == "4")) poen ++;
            listBox4.SelectedIndex -= poen;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            button3.Visible = false;
            button2.Visible = false;
            button5.Visible = false;
            button6.Visible = false;
            listBox4.Visible = false;
            radioButton1.Visible = false;
            radioButton2.Visible = false;
            radioButton3.Visible = false;
            radioButton4.Visible = false;
            label1.Visible = false;
            button1.PerformClick();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button2.Visible = true;
            button3.Visible = true;
            button5.Visible = true;
            button6.Visible = true;
            listBox4.Visible = true;
            radioButton1.Visible = true;
            radioButton2.Visible = true;
            radioButton3.Visible = true;
            radioButton4.Visible = true;
            label1.Visible = true;
            button4.Visible = false;
            listBox4.SelectedIndex = 15;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("NISI ZNAO ODGOVOR NA PITANJE!! Zaradio si " + listBox4.Text + " dinara.");
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int k = listBox1.Items.Count;
            maxbroj = k;
            Random x = new Random();
            int pitanje = x.Next(0, maxbroj);
            trenutno = pitanje;
            label1.Text = listBox1.Items[pitanje].ToString();
            int odgovor = pitanje * 4;
            radioButton1.Text = listBox2.Items[odgovor].ToString();
            radioButton2.Text = listBox2.Items[odgovor + 1].ToString();
            radioButton3.Text = listBox2.Items[odgovor + 2].ToString();
            radioButton4.Text = listBox2.Items[odgovor + 3].ToString();
            button6.Visible = false;
        }
    }
}
