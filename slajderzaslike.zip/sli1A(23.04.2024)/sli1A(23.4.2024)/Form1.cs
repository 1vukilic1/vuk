﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace sli1A_23._4._2024_
{
    public partial class Form1 : Form
    {
        int pozicija = -1;
      
        public Form1()
        {
            InitializeComponent();
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DirectoryInfo folder = new DirectoryInfo(@"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2");
            FileInfo[] slike = folder.GetFiles("*.jpg");
            foreach (FileInfo file in slike)
            {
                listBox1.Items.Add(file.Name);
            }
            string naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[0].ToString();
            pictureBox1.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[1].ToString();
            pictureBox2.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[2].ToString();
            pictureBox3.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[3].ToString();
            pictureBox4.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[4].ToString();
            pictureBox5.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[2].ToString();
            panel3.BackgroundImage = Image.FromFile(naziv);
            pozicija = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pozicija++;
            string naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija].ToString();
            pictureBox1.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija+1].ToString();
            pictureBox2.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija + 2].ToString();
            pictureBox3.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija + 3].ToString();
            pictureBox4.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija + 4].ToString();
            pictureBox5.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija + 2].ToString();
            panel3.BackgroundImage = Image.FromFile(naziv);
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pozicija--;
            string naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija].ToString();
            pictureBox1.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija + 1].ToString();
            pictureBox2.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija + 2].ToString();
            pictureBox3.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija + 3].ToString();
            pictureBox4.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija + 4].ToString();
            pictureBox5.BackgroundImage = Image.FromFile(naziv);
            naziv = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\slike2\" + listBox1.Items[pozicija + 2].ToString();
            panel3.BackgroundImage = Image.FromFile(naziv);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = true;
            button3.Visible = true;
            button4.Visible = false;
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
        }
    }
}
