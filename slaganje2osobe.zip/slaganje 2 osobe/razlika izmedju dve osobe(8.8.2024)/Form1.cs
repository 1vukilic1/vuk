﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace razlika_izmedju_dve_osobe_8._8._2024_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.Visible = false;
            button2.Visible = true;
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            textBox5.Visible = false;
            textBox6.Visible = false;
            textBox7.Visible = false;
            textBox8.Visible = false;
            textBox9.Visible = false;
            textBox10.Visible = false;
            textBox11.Visible = false;
            textBox12.Visible = false;
            textBox13.Visible = false;
            textBox14.Visible = false;
            textBox15.Visible = false;
            textBox16.Visible = false;
            textBox17.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            label10.Visible = false;
            label11.Visible = false;
            dateTimePicker1.Visible = false;
            dateTimePicker2.Visible = false;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = dateTimePicker1.Text;
            string s2 = dateTimePicker2.Text;
            string d = "" + s[0] + s[1];
            textBox1.Text = d;
            string m = "" + s[3] + s[4];
            textBox2.Text = m;
            string g = "" + s[7] + s[8] + s[9] + s[10];
            textBox3.Text = g;

            string d1 = "" + s2[0] + s2[1];
            textBox6.Text = d1;
            string m1 = "" + s2[3] + s2[4];
            textBox5.Text = m1;
            string g1 = "" + s[7] + s[8] + s2[9] + s2[10];
            textBox4.Text = g1;

            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                string txt = textBox1.Text;
                int suma = 0;
                foreach (char br in txt)
                {
                    if (char.IsDigit(br))
                    {
                        suma += int.Parse(br.ToString());
                    }
                }
                textBox7.Text = Convert.ToString(suma);
            }
            if (!string.IsNullOrEmpty(textBox2.Text))
            {
                string txt = textBox2.Text;
                int suma = 0;
                foreach (char br in txt)
                {
                    if (char.IsDigit(br))
                    {
                        suma += int.Parse(br.ToString());
                    }
                }
                textBox10.Text = Convert.ToString(suma);
            }
            if (!string.IsNullOrEmpty(textBox3.Text))
            {
                string txt = textBox3.Text;
                int suma = 0;
                foreach (char br in txt)
                {
                    if (char.IsDigit(br))
                    {
                        suma += int.Parse(br.ToString());
                    }
                }
                textBox11.Text = Convert.ToString(suma);
            }
            if (!string.IsNullOrEmpty(textBox6.Text))
            {
                string txt = textBox6.Text;
                int suma = 0;
                foreach (char br in txt)
                {
                    if (char.IsDigit(br))
                    {
                        suma += int.Parse(br.ToString());
                    }
                }
                textBox8.Text = Convert.ToString(suma);
            }
            if (!string.IsNullOrEmpty(textBox5.Text))
            {
                string txt = textBox5.Text;
                int suma = 0;
                foreach (char br in txt)
                {
                    if (char.IsDigit(br))
                    {
                        suma += int.Parse(br.ToString());
                    }
                }
                textBox12.Text = Convert.ToString(suma);
            }
            if (!string.IsNullOrEmpty(textBox4.Text))
            {
                string txt = textBox4.Text;
                int suma = 0;
                foreach (char br in txt)
                {
                    if (char.IsDigit(br))
                    {
                        suma += int.Parse(br.ToString());
                    }
                }
                textBox13.Text = Convert.ToString(suma);
            }
            if (int.TryParse(textBox7.Text, out int broj1) && int.TryParse(textBox10.Text, out int broj2) && int.TryParse(textBox11.Text, out int broj3))
            {
                int zbir = broj1 + broj2 + broj3;
                textBox14.Text = Convert.ToString(zbir);
            }
            if (int.TryParse(textBox8.Text, out int broj4) && int.TryParse(textBox12.Text, out int broj5) && int.TryParse(textBox13.Text, out int broj6))
            {
                int zbir = broj4 + broj5 + broj6;
                textBox15.Text = Convert.ToString(zbir);
            }
            if (!string.IsNullOrEmpty(textBox14.Text))
            {
                string txt = textBox14.Text;
                int suma = 0;
                foreach (char br in txt)
                {
                    if (char.IsDigit(br))
                    {
                        suma += int.Parse(br.ToString());
                    }
                }
                textBox16.Text = Convert.ToString(suma);
            }
            if (!string.IsNullOrEmpty(textBox15.Text))
            {
                string txt = textBox15.Text;
                int suma = 0;
                foreach (char br in txt)
                {
                    if (char.IsDigit(br))
                    {
                        suma += int.Parse(br.ToString());
                    }
                }
                textBox17.Text = Convert.ToString(suma);
            }
            if (textBox16.Text == textBox17.Text)
            {
                textBox9.Text = " 100 %";
            }
            if (Convert.ToInt32(textBox16.Text) > Convert.ToInt32(textBox17.Text))
            {
                int z1, z2;
                z1 = Convert.ToInt32(textBox16.Text) - Convert.ToInt32(textBox17.Text);
                z2 = 100 - (z1*10);
                textBox9.Text = Convert.ToString( z2 + " %");
            }
            else
            {
                int z1, z2;
                z1 = Convert.ToInt32(textBox17.Text) - Convert.ToInt32(textBox16.Text);
                z2 = 100 - (z1*10);
                textBox9.Text = Convert.ToString( z2 + " %");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = false;
            textBox1.Visible = true;
            textBox2.Visible = true;
            textBox3.Visible = true;
            textBox4.Visible = true;
            textBox5.Visible = true;
            textBox6.Visible = true;
            textBox7.Visible = true;
            textBox8.Visible = true;
            textBox9.Visible = true;
            textBox10.Visible = true;
            textBox11.Visible = true;
            textBox12.Visible = true;
            textBox13.Visible = true;
            textBox14.Visible = true;
            textBox15.Visible = true;
            textBox16.Visible = true;
            textBox17.Visible = true;
            label1.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;
            label9.Visible = true;
            label10.Visible = true;
            label11.Visible = true;
            dateTimePicker1.Visible = true;
            dateTimePicker2.Visible = true;
        }
    }
}
