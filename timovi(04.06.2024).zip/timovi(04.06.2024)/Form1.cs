﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace timovi_04._06._2024_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
    
        }
        string put1 = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\timovi(04.06.2024)\prvi.txt";
        string put2 = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\timovi(04.06.2024)\drugi.txt";
        string kvota1 = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\timovi(04.06.2024)\prvakvota.txt";
        string kvota2 = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\timovi(04.06.2024)\drugakvota.txt";
        string kvota3 = @"D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\timovi(04.06.2024)\trecakvota.txt";
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button3.PerformClick();
            foreach(var item in listBox1.Items)
            {
                comboBox4.Items.Add(item);
            }
            foreach (var item in listBox3.Items)
            {
                comboBox3.Items.Add(item);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string FilePath = put1;
            string FilePath2 = put2;
            string FilePath3 = kvota1;
            string FilePath4 = kvota2;
            string FilePath5 = kvota3;
            if (File.Exists(FilePath))
            {
                using (StreamReader sr = new StreamReader(FilePath))
                {
                    string line;
                    while((line=sr.ReadLine())!=null)
                        {
                        listBox1.Items.Add(line);
                    }
                }
            }
            else
            {
                MessageBox.Show("Fajl ne postoji.");
            }
            if (File.Exists(FilePath))
            {
                using (StreamReader sr = new StreamReader(FilePath3))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        listBox2.Items.Add(line);
                    }
                }
            }
            else
            {
                MessageBox.Show("Fajl ne postoji.");
            }
            if (File.Exists(FilePath))
            {
                using (StreamReader sr = new StreamReader(FilePath2))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        listBox3.Items.Add(line);
                    }
                }
            }
            else
            {
                MessageBox.Show("Fajl ne postoji.");
            }
            if (File.Exists(FilePath))
            {
                using (StreamReader sr = new StreamReader(FilePath4))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        listBox4.Items.Add(line);
                    }
                }
            }
            else
            {
                MessageBox.Show("Fajl ne postoji.");
            }
            if (File.Exists(FilePath))
            {
                using (StreamReader sr = new StreamReader(FilePath5))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        listBox5.Items.Add(line);
                    }
                }
            }
            else
            {
                MessageBox.Show("Fajl ne postoji.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s0 = Convert.ToString(listView1.Items.Count + 1);
            string s1 = comboBox1.Text;
            string s2 = comboBox3.Text;
            string s3 = comboBox4.Text;
            string[] s = { s0, s3, s2,s1 };
            var upis = new ListViewItem(s);
            listView1.Items.Add(upis);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string naziv =@" D:\III Programiranje\Grupa A\Vuk Ilic\programiranje\C#\timovi(04.06.2024)\snimaj.txt";
            System.IO.StreamWriter snimi = new System.IO.StreamWriter(naziv);
            int k = listView1.Items.Count;
            for (int i = 0; i < k; i++)
            {
                string s = listView1.Items[i].ToString();
                snimi.WriteLine(s);
            }
            snimi.Close();
            MessageBox.Show("SNIMLJENO!!");
        }

        private void comboBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox4_TextChanged(object sender, EventArgs e)
        {
            if (comboBox4.SelectedIndex == 0)
            {
                comboBox3.SelectedIndex = 0;
            }
            if (comboBox4.SelectedIndex == 1)
            {
                comboBox3.SelectedIndex = 1;
            }
            if (comboBox4.SelectedIndex == 2)
            {
                comboBox3.SelectedIndex = 2;
            }
            if (comboBox4.SelectedIndex == 3)
            {
                comboBox3.SelectedIndex = 3;
            }
            if (comboBox4.SelectedIndex == 4)
            {
                comboBox3.SelectedIndex = 4;
            }
        }
    }
}
