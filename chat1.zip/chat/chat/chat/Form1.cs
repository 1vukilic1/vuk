﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;
using static System.Windows.Forms.LinkLabel;

namespace chat
{
    public partial class Form1 : Form
    {
        string username;
        string chat = @"\\192.168.123.96\podaci2\chat34.txt";
        string korisnici = @"\\192.168.123.96\podaci2\korisnici.txt";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tekst = textBox1.Text;
            if (tekst!="")
            {
                StreamWriter ko = new StreamWriter(korisnici, true);
                ko.WriteLine(tekst);
                ko.Close();
                tabControl1.SelectedIndex = 1;
                timer1.Enabled = true;
                username = textBox1.Text;
                textBox1.Text = "";
                listBox2.Items.Clear();
                listBox2.Items.AddRange(File.ReadAllLines(korisnici));
                listBox1.Items.Clear();
                listBox1.Items.AddRange(File.ReadAllLines(chat));
            }
            else
            {
                MessageBox.Show("Unesite ime pre nego sto pristupite porukama.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string provera;
            listBox2.Items.AddRange(File.ReadAllLines(korisnici));
            for (int i = 0; i < listBox2.Items.Count; i++)
            {
                provera = listBox2.Items[i].ToString();
                if (provera == username)
                {
                    string[] ukloni = File.ReadAllLines(korisnici);
                    ukloni = Array.FindAll(ukloni, line => !line.Contains(username));
                    File.WriteAllLines(korisnici, ukloni);
                    listBox2.Items.Clear();
                    listBox2.Items.AddRange(File.ReadAllLines(korisnici));
                }
            }
            tabControl1.SelectedIndex = 0;
            timer1.Enabled = false;
            listBox1.Items.Clear();
            listBox2.Items.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string s = username + ": " + textBox2.Text;
            StreamWriter poruka = new StreamWriter(chat, true);
            poruka.WriteLine(s);
            poruka.Close();
            listBox1.Items.Add(s);
            textBox2.Text = "";
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            try
            {
                listBox1.Items.AddRange(File.ReadAllLines(chat));
            }
            catch (IOException e1)
            {
                MessageBox.Show("Nije moguce ucitati poruke: " + e1.Message);
            }
            try
            {
                listBox2.Items.AddRange(File.ReadAllLines(korisnici));
            }
            catch (IOException e2)
            {
                MessageBox.Show("Nije moguce ucitati korisnike: " + e2.Message);
            }
        }
    }
}
