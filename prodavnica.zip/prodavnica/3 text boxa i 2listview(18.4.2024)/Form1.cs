﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _3_text_boxa_i_2listview_18._4._2024_
{
    public partial class Form1 : Form
    {
        int selektovan = -1;
        string putanja = @"d:\III Programiranje\Grupa A\Vuk Ilic\pit\3 text boxa i 2listview(18.4.2024)\povrce.txt";
        string putanja1 = @"d:\III Programiranje\Grupa A\Vuk Ilic\pit\3 text boxa i 2listview(18.4.2024)\voce.txt";
        string putanja2 = @"d:\III Programiranje\Grupa A\Vuk Ilic\pit\3 text boxa i 2listview(18.4.2024)\sokovi.txt";
        string snimi = @"d:\III Programiranje\Grupa A\Vuk Ilic\pit\3 text boxa i 2listview(18.4.2024)\snimljeno.txt";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex= 1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = File.ReadAllLines(putanja2);
            listView1.Items.Clear();
            int broj = 1;
            for (int i = 0; i < listBox1.Items.Count; i += 2)
            {
                string[] zapis = { (broj).ToString(), listBox1.Items[i].ToString(), listBox1.Items[i + 1].ToString() };
                var red = new ListViewItem(zapis);
                listView1.Items.Add(red);
                broj++;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            listView2.Items[selektovan].Remove();
            button9.PerformClick();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int brojac = listView2.Items.Count;
            for (int i = 0; i < brojac; i++)
            {
                listView2.Items[i].SubItems[0].Text = Convert.ToString(i + 1);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            listView2.Items[selektovan].SubItems[2].Text = textBox2.Text;
            int redi = listView1.SelectedIndices[0];
            int reds = listView2.SelectedIndices[0];
            int zbir = Convert.ToInt32(listView1.Items[redi].SubItems[2].Text) * Convert.ToInt32(textBox2.Text);
            listView2.Items[reds].SubItems[4].Text = Convert.ToString(zbir);
            textBox2.Text = "";
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = File.ReadAllLines(putanja);
            listView1.Items.Clear();
            int broj = 1;
            for (int i = 0; i < listBox1.Items.Count; i += 2)
            {
                string[] zapis = { (broj).ToString(), listBox1.Items[i].ToString(), listBox1.Items[i + 1].ToString() };
                var red = new ListViewItem(zapis);
                listView1.Items.Add(red);
                broj++;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.DataSource = File.ReadAllLines(putanja1);
            listView1.Items.Clear();
            int broj = 1;
            for (int i = 0; i < listBox1.Items.Count; i += 2)
            {
                string[] zapis = { (broj).ToString(), listBox1.Items[i].ToString(), listBox1.Items[i + 1].ToString() };
                var red = new ListViewItem(zapis);
                listView1.Items.Add(red);
                broj++;
            }

        }

        private void button10_Click(object sender, EventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count>0 && textBox1.Text!="")
            {
                int redd = listView1.SelectedIndices[0];
                int zbir = Convert.ToInt32(listView1.Items[redd].SubItems[2].Text) * Convert.ToInt32(textBox1.Text);
                string[] zapis = { (listView2.Items.Count + 1).ToString(), listView1.Items[redd].SubItems[1].Text, textBox1.Text,listView1.Items[redd].SubItems[2].Text,zbir.ToString()};
                var reda = new ListViewItem(zapis);
                listView2.Items.Add(reda);
                textBox1.Text = "";
            }
            label1.Text = Convert.ToString(listView2.Items.Count);
        }

        private void listView2_Click(object sender, EventArgs e)
        {
            int red = listView2.SelectedIndices[0];
            selektovan = red;
            textBox2.Text = listView2.Items[red].SubItems[2].Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
           
        }
    }
}
