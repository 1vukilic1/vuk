﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace listview1_16._4._2024_
{
    public partial class Form1 : Form
    {
        int selektovan = -1;
        public Form1()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int brojac = listView1.Items.Count;
            string s1 = Convert.ToString(brojac + 1);
            string s2 = textBox1.Text;
            string s3 = textBox2.Text;
            string s4 = textBox3.Text;
            string[] zapis = { s1, s2, s3, s4 };
            var red = new ListViewItem(zapis);
            listView1.Items.Add(red);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void listView1_Click(object sender, EventArgs e)
        {
            int red = listView1.SelectedIndices[0];
            selektovan = red;
            textBox1.Text = listView1.Items[red].SubItems[1].Text;
            textBox2.Text = listView1.Items[red].SubItems[2].Text;
            textBox3.Text = listView1.Items[red].SubItems[3].Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listView1.Items[selektovan].SubItems[1].Text = textBox1.Text;
            listView1.Items[selektovan].SubItems[2].Text = textBox2.Text;
            listView1.Items[selektovan].SubItems[3].Text = textBox3.Text;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listView1.Items[selektovan].Remove();
            button4.PerformClick();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int brojac = listView1.Items.Count;
            for(int i=0;i<brojac;i++)
            {
                listView1.Items[i].SubItems[0].Text = Convert.ToString(i + 1);
            }
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }
    }
}
